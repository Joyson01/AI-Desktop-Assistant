import speech_recognition as sr

class SpeechService:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.calibrated = False
    def listen(self):
        try:
            with sr.Microphone() as source:
                if not self.calibrated:
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                    self.calibrated = True
                try: return self.recognizer.listen(source, timeout=5, phrase_time_limit=8)
                except sr.WaitTimeoutError: return None
        except (OSError, AttributeError) as error:
            print(f"[ERROR] component=stt_listen exception={type(error).__name__}: {error}")
            return None
    def speech_to_text(self, audio):
        if audio is None: return ""
        try: return self.recognizer.recognize_google(audio, language="en-IN").strip().lower()
        except sr.UnknownValueError:
            return ""
        except sr.RequestError as error:
            print(f"[ERROR] component=stt_transcription exception={type(error).__name__}: {error}")
            return ""
