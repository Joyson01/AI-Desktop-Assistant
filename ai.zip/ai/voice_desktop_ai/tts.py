import subprocess

def speak(message):
    print(f"Assistant: {message}")
    escaped = str(message).replace("'", "''")
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-Command", "Add-Type -AssemblyName System.Speech; $s=New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Rate=-1; $s.Speak('" + escaped + "')"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        pass
