# MARUTI

MARUTI is a Windows voice assistant with local speech, OCR, PyAutoGUI and
pywinauto controls. Gemini is optional and is never required for local actions.

## Setup

```powershell
cd D:\NehruCode\ai\voice_desktop_ai
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Create a local `.env` file when Gemini is needed:

```text
GEMINI_API_KEY=your-key-here
```

Do not commit `.env`. The application remains usable without the key and
reports that the Gemini brain is not configured.

## Run

```powershell
.\.venv\Scripts\python.exe assistant.py
```

Run tests with:

```powershell
.\.venv\Scripts\python.exe -m pytest tests -q
```

OCR requires the Tesseract executable on Windows. Set `TESSERACT_CMD` when it
is not installed in a standard location.